#!/system/bin/bash

SYSTEM="$MODPATH/system/"

echo -e "
┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ㅤGI Rebornㅤㅤㅤㅤㅤㅤㅤㅤ‏ㅤ SIMON
┃"

echo "┣ Setting permissions..."
set_permissions() {
    set_perm_recursive $MODPATH 0 0 0777 0755
    set_perm $MODPATH/service.sh 0 0 0755
    set_perm $MODPATH/mask_force_all.sh 0 0 0755
    set_perm $MODPATH/system.prop 0 0 0777
    set_perm $SYSTEM/ZONE-X/.dev_block_connected 0 0 7677
    set_perm $SYSTEM/ZONE-X/ZONE 0 0 7666
    set_perm $SYSTEM/ZONE/.no_dev_connected 0 0 6777
}
set_permissions
echo -e "┃\n┣ Setting permissions successfully..\n┃"

echo -e "┃\n┣ Setting up GIReborn_AutoStart directory...\n┃"

autostart_dir="/data/local/GIReborn_AutoStart"

if [ ! -d "$autostart_dir" ]; then
    echo "┃ Target directory does not exist. Creating..."
    su -c "mkdir -p '$autostart_dir'"
    echo "┃ Target directory created: $autostart_dir"
else
    echo "┃ Target directory already exists: $autostart_dir"
fi

echo -e "┃\n┗ Initialization script completed successfully!\n"